package com.example.video_live_translation

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
